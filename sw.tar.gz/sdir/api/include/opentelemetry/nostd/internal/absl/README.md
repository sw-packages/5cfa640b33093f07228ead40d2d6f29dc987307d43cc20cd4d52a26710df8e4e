# Notes on Abseil Variant implementation

This is a snapshot of Abseil Variant
`absl::OTABSL_OPTION_NAMESPACE_NAME::variant` from Abseil `v2020-03-03#8`.
